In the Zip file you should have

IPINS.TXT				DONT MODIFY
KATSB.TXT			DONT MODIFY
WinceSB.TXT			DONT MODIFY
SELFBOOTHELPER.EXE		THE Win32 FRONTEND TO CD-RECORD
README.TXT			THIS TEXT FILE

EXTRACT ALL THE FILEZ TO THE SELFBOOT DIRECTORY WHICH SHOULD ALREADY CONTAIN ECHELON'S BINHACK AND IPINS EXECUTABLES ALONG WITH THE CDRECORD FILES.

Run SelfBootHelper.EXE
Enter the CD Reader Drive letter (This is Just the letter E.G. If it is the D:\ Drive then Enter D)
The Prog will detect the name of the Boot.bin File
Click Copy Files (This will Copy all the files on the CD and will also do all the SubDirectorys No Matter what the depth)
Close The Window When it has Finished
Enter the SCSI Bus ID of your CD Writer 
	To find this Go into Dos [START, RUN, Type in COMMAND, Press Enter] 
	Type CD\Selfboot
	Type CDRECORD -SCANBUS
	Look for your CDWRITER and note the number next to it
	IT WILL Look like this 0,4,0
Enter the Maximum Writing Speed of your CD Writer
Click GO For it and the CD will Be Burned Thats it.
Close the Window
Click Restart and then enter your next game and then goto step 2
Have Fun!!!!

PROFFRINK