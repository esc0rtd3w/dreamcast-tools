===================================================
DCi - Dreamcast CD image tool 1.1 for DOS by Jules
===================================================
Readme & FAQ in one.

New in 1.1
- no longer loads entire cd image into memory,
  so now you can patch cd images which size is
  bigger then your RAM size.
- removed "create new patched image" feature 
  so now you can only patch the image, not create new patched one.
  this was removed to due to the lack of time & the "not load
  cd image into memory" feature.

New in 1.0a
- Fixed serious fread() bug

Version 1.0 did not work, sorry about that.
The bug is fixed and it should work properly now.

Q: What is DCi ?
A: DCi is a little util which insert your bootfile
(ip.bin) into Nero Burning Rom or ISO9660 images.
So it boots on your Dreamcast.

Q: How Do I use DCi?
A: Read the information when you execute the program.

Q: How Do make the cd image and the rest of the
   bootable CD using Nero Burning Rom format?
A: http://jules.rules.it has a tutorial

Q: How Do make the cd image and the rest of the
   bootable CD using ISO9660 format?
A: http://jules.rules.it has links to sites which
   provide this information.

Q: Where can I get DCi ?
A: http://jules.rules.it

Q: What is Jules' email?
A: jules.dc@gmx.net
 
/Jules