This is a very quick port of SMS+SDL 7.1 by Gregory Montoir which was based on
0.9.4a of SMS Plus by Charles Mac Donald.

Put your .sms and .gg ROMs in /roms and burn.

The menu is a bit ugly, and not nearly as good as I'd like. There's currently
no way to get back to the menu when you play a ROM - this was just a test port
and I'll most likely no work on it anymore.

The ROM list code was taken from BlueCrab's SMS\GG\SG-1000 emulator, CrabEmu so
all credits goes to him for that.

- fackue
