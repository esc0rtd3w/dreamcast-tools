AFS->ADX unpacker V0.2
Copyright 1997-2002 Jefferson Leandro Ramos Ricci aka Verdi Kasugano
(verdi@kasugano.cjb.net)

Freeware program, leasing or sold is not permited

"README's is not my passion" ! ;)

* Just extract ADX samples in AFS archives of some Dreamcast(tm) games!

Usage:

   afs2adx archivename.afs [-all]

* "-all" option is optional, the program extract all data in archive, not
only ADX samples. Unless this option is given, the program only extract
ADX's samples. I seen some archives containing some dummy ADX's samples.
These "dummy's" is only extracted with the "-all" option. Other data is
extracted with "RAW" extension.

* The files extracted are in sequences

* The program uses LFN (long filenames) functions, use the program with
  running Win9X(tm) or compatible system

* Do not distribute illegal data, is dangerous for you !


Changes since V0.1

  * Wildcards accepted
  * Bug fixed in detecting ADX sample

FAQ:

Q: Where I can play ADX files ?
A: Get a plugin for Winamp(tm) or any ADX->WAV(E) converter

Future:

* Maybe add a "packer" module
* Option to extract in WAVE format
* Maybe GUI (hmmm, I like command line... and you ?)

I found the web some AFS decoders with sources, I learn AFS structure by
myself and wrote my decoder. Just use anyone as you wish ! ;)

Any bugs ??? email-me !

Copyrights
----------
Windows(tm) <-> Microsoft Corporation
Dreamcast(tm) <-> SEGA
Winamp(tm) <-> NullSoft
ADX <-> CRI (???)
AFS <-> (???) "unsure"

The author can't be responsible for wrong use of this program !

<eof>


