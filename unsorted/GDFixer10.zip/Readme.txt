GD FIXER 1.0 Publica
25/5/2001

By Yursoft

.Informacion:

Viendo que ya existen utilidades parecidas a la mia, y que el tema de desproteger es un secreto a voces he decidido realizar una version Publica de mi utilidad. En realidad es una version Lite, Light o abreviada como querais llamarlo, debido a que la que tengo hecha para mi uso privado incluye m�s opciones. 
El por qu� he querido hacerlo Light, es debido a que no es necesario mas opciones para hacer funcionar un juego de Dreamcast "normal", no me digais que por que no os funciona el Jet Set Radio y demas juegos por que no tienen una proteccion sencilla y que sea facil de desproteger (Juegos asi os lo podias currar y comprar... ;))

.Informacion del programa:

Los juegos de Dreamcast tienen una proteccion que hace que solo arranquen en el sector de donde estan grabados originalmente, debido ha esto necesitas modificar los ficheros 1st_read.bin, 2_dp.bin, maigo.bin y sg_dplr.bin, de esta forma arrancaran con Boot CD y Autoejecutables.

.Requiere:

- Los ficheros originales del GD, no valen los que ya estan modificados por otros programas.
- Necesitas saber el SECTOR donde empieza la sesion de datos que vas ha grabar, en el caso del BOOT CD el sector es el 0. 
Este Sector lo puedes sacar con el kit de autoejecutables que utilizas.

Ejemplo: 
	 Utilizando el sistema de Echelon te dice que con:
		
          cdrecord -dev=x,x,x -msinfo  (donde x,x,x es el valor SCSI ID de tu grabadora)

	 Te debe aparecer un valor 0,11702 (puede ser diferente, segun la primera sesion)
	 Entonces lo unico que debes poner es la parte de la derecha de la coma (11702).

.Como Fixear:

Arrancas el programa, seleccionas el fichero a fixear y presionas GD Hack, te preguntara si tiene pistas de audio (asegurate de que las tiene!!) presionas SI o NO, el proceso te informara con un se�al en el cuadro de informacion que modificaciones ha realizado.


Si has respondido afirmativamente a la pregunta del audio, luego tienes que pulsar 
AUDIO HACK, (esta opcion solo esta disponible cuando fixees el fichero 1st_read.bin).
El Audio Hack te permite no tener que introducir 2 pistas de audio extras antes que las del juego.


Ciertos juegos tienen una proteccion extra, en este caso el programa te preguntara si quieres parchearla. La desproteccion no siempre es efectiva, e incluso puede producir un efecto negativo en la ejecucion del juego.


Recuerda parchear todos los ejecutables que te aparezcan en el cuadro de abrir.


Si pulsas DETALLES te aparecera un cuadro donde te dira que parte del fichero a modificado. (No es necesario ni mirarlo ;))

NOTA: Los juegos de WINCE aun no estan soportados pero en las siguientes versiones estaran disponibles.


Aqui me despido hasta el proximo programa :)

RECORDAD QUE EL HACER UNA COPIA DE UN JUEGO DEL QUE NO ERES POSEEDOR ES UN DELITO TIPIFICADO. SI ESTAIS USANDO ESTE PROGRAMA PARA ESTE FIN, POR FAVOR BORRALO DE TU DISCO DURO.


PD: Poco a poco ire sacando m�s programas que tengo en el horno :)

YURSOFT <-------------------------------------------------------------------> TFOSRUY 