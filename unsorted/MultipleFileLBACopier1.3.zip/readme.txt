Multiple File LBA Copier

This, like the single file version, will allow you to use the same data
on a CD for two or more files in the file system. It uses a script to
do this, which you can generate from a list of CRCs (will automatically
find duplicates) or you can create yourself. The format is as follows:

5		; the number of files to contain identical data
"1STFILE.BIN"	; the file containing the actual data
"2NDFILE.BIN"	; file(s) to be be patched to the same data as above
"3RDFILE.BIN"
"4THFILE.BIN"
"5THFILE.BIN"
2		; etc
"1STFILE.BIN"
"2NDFILE.BIN"

These patched files MUST be present (as 0 byte files) in the CDFS file
system. The first file must be the file to contain the actual data.

You can automatically generate a script, by first using crc32.exe to
calculate a crc32 of all the files. This will create a script of any
duplicate files as well as a batch file you can use to create/overwrite
the duplicate files with 0 byte versions (uses newfile.exe).

This only works for a single directory. The process is as follows:

crc32 *.* > crc32.txt

Put the correct location of crc32.txt into the relevant field in the
patcher program. Click "Generate" and it will generate a script to the
filename specified in the script field. It will also create zero.bat
in the same directory as the patcher program, move it to the directory
containing your files and execute it there (you must have newfile.exe
somewhere in your path).

Now, delete zero.bat and build your ISO as normal. Finally, click
"Copy" to patch the files inside the ISO using your script. It's a good
idea to open your script first and take a look at it.

There's virtually no error checking in this program so be careful with
its usage and make sure you follow the directions properly.