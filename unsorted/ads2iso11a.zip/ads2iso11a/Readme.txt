Program name: ADS2ISO
Author      : Michal Turlik   --   @mt@
Date        : 07/18/2002

For use with   : Echelon's selfboot toolkit + Jorg Schilling Cdrecord software.
Application    : For make selfbootable dc cd games using DATA+DATA(mode2) tracks.
What does it do: Appends some dummy sectors to an iso image file to make it 33598 sectors sized.

USAGE       : root\ads2iso <isoimage.iso>
Example     : mypath\ads2iso myimage.iso


--Some info--

Making this new selfbootable method working is to merge the latest track with 
the first one.
It is possible using CDrWin or using Cdrecord, personally I chosen Cdrecord.
I have to say that it is a tedious procedure in matching LBA 45000 offset for the 2nd track.
I am not certain of it but surelly new console hardware, I am referring to new Dreamcast 
console, require the LBA 45000 offset for the 'boot' file.

For having an offset of 45000 you should do this calcolous:
1 st track must be of 68.808.704 bytes that means 33598 sectors(68.808.704/2048)
The remaining 11402 sectors will be used by the lead-out(lout) track.
So we have an offset of 45000 sectors (33598 sectors used by our track
and the remaining 11402 used by the lout).
It is not possible by making an iso image file that would be fitting 33598 sectors.
So it is necessary to create (for example) an iso image file of 68,780,032 bytes(33584 sectors) 
and then hack it in manner to make it 33598 sectors fitting.
So let's start in making our games selfbootable from LBA 45000:

-It is necessary to select game data to be stored in the first track, generally they may not 
exceed ~ 64 Mbytes.
-It is possible to make the '1st_read.bin' file part of the first track but I do not suggest it...it 
will be a lot more tedoius work as it just is.
-Now it is time to create our first track:
Suppose to have made a directory called 'DATA' and stored in it all files selected for the 
1st track you have to manage this:

\root\mkisofs -V LABEL_ID -T -l -o TRACK01.iso \root\DATA

-Now that you have your image file less than 33598 sectors it is time to hack it:

\root\ads2iso TRACK01.iso

-Burn it in your cd-r. drive:

\root\cdrecord -dev=x,x,x -multi -xa1 -speed=y TRACK01.iso

-After this it is needed to check the layout offset:

\root\cdrecord -dev=x,x,x -msinfo

-It will be: 0,45000
-At this time the first track has been written.

--Time for binhack and the 2nd track creation:

-From all game data files that was not chosen for the 1st track you have to take apart the 
'1st_read.bin' and the 'ip.bin' files 
(take any ip.bin file from any not-selfbootable game if you can not extract it from the 
boot sector of the cd game) and do this:

\root\binhack.exe
(for the first parameter type: 1st_read.bin, for the second: ip.bin, for the third: 45000)

-Now you have to create a second track data with the other game files you left before 
(including the 1st_read.bin).
Suppose to have created another directory called DATA2 with all the other game data inside 
(those data you have left before)
In this folder you have to put the '1st_read.bin' file hacked before, too.
So write on your command line:

\root\mkisofs -C 0,45000 -V LABEL_ID -M TRACK01.iso -l -o TRACK02.iso \root\DATA2

then:

\root\ipins.exe (first parameter: ip.bin, the second one: TRACK02.iso)

And finally:

\root\cdrecord -dev=x,x,x -xa1 -speed=y TRACK02.iso

After burning fineshed try it in your Dc.

To understand all I have wrote you have to refer to the Echelon's selfboot guide.
Some steps I have wrote are not explaining all in detail!
To use this method you have to download the Echelon's selfboot kit!

