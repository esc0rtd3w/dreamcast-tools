dc-tool GUI 2.0.2
http://dchelp.dcemulation.com/

A GUI for dc-tool Serial and IP.

What's new:
- A few new checks to make sure everything isn't missing before uploading (CDFS
  redir)
- Uses CodeBlock's console runner to keep the console open after dc-tool closes
- A few other things that I can't remember

History:
- New: Major source overhaul
- New: GDB switch "-g" supported
- New: External baud switch "-E" supported
- New: Reset dc-load IP switch "-r" supported
- New: dc-tool Serial 1.0.4
- Fix: Lots of minor changes
- Chroot support has been temp. disabled
2.0.0b
- Download syscalls.bin option
- ability to check for updates

2.0.0a
- source code cleaned

2.0
- download the BIOS
- download the Flash
- now uses dc-tool IP 1.0.4
- now uses dc-tool serial 1.0.3
- completely rewritten
- removed COMDLG32.OCX dependency

1.0
- Chroot implemented

0.5
- support for upload, upload and execute, and download
- all command line parameter besides Chroot implemented

0.1
- initial release