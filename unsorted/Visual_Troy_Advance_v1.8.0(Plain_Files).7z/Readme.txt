Build by SWAT
http://www.dc-swat.net.ru



This is a port of 1.8.0 of VisualBoyAdvance which i have cleverly refer to as Visual Troy Advance :)


Thanks to everyone who helped get it this far.
BlackAura for his 2d video display code for the menu's
Chui's port of vba32 for gp32
Wacko for his splashscreen
Wraggster from dcemu.co.uk for his contributions to the Dreamcast scene (and towards my new bba-thanks again)

and Special Thanks to
Forgotten (http://vba.ngemu.com/contact.shtml)
kxu <kxu@users.sourceforge.net>

http://vba.ngemu.com
http://sourceforge.net/projects/vba

for releasing the source so that I could port it, go to his site and make a donation he deserves it.

=========================

This is a very beta build right now I have removed all SDL dependancies.

Sound is not quite right either, clicks and sputters occasionally disable sound fixes that :)


Press both triggers and start to return to the menu and keep pressing start to return to previous menu or back to gameplay.
X = B 
A = A 
L Trigger = L 
R Trigger = R 
Start = Start 
Y = Select 

Emulator support nested directories for roms.


Enjoy, download the source and improve it please :)

Thanks,
Troy Davis (GPF)
http://gpf.dcemu.co.uk/





