Source released under the terms of the GNU GENERAL PUBLIC LICENSE v2.
This was written in Borland Delphi 6 (should compile fine in Delphi 5).
I've included the DirDlg component (required to build the GUI version),
as the author's homepage is no longer functional.

mrtool_core.pas contains the bulk of the actual MR [en|de]coder. mrtool
is the Win32 command-line wrapper, mrtool_gui is the Win32 GUI wrapper.

Do with as you will, but remember, if you base something upon this, you
must release source.

- krypt@mountaincable.net