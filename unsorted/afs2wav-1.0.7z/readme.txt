  [big_fury]
  888888888    8888  888888888888  8888     888888888     8888      8888   888888888
8888888888888  8888  888888888888  8888   8888888888888   8888      8888 8888888888888
8888     8888              88888         8888       8888  8888      8888 8888     8888
888888888      8888      888888    8888 8888         8888 8888      8888 888888888
  8888888888   8888     88888      8888 8888         8888 8888      8888   88888888888
       888888  8888   88888        8888 8888         8888 8888      8888         888888
8888      8888 8888  88888         8888  8888       8888  8888      8888 8888      8888
8888888888888  8888 88888888888888 8888   8888888888888    888888888888  8888888888888
  8888888888   8888 88888888888888 8888     888888888       8888888888     8888888888



AFS2WAV [ADXUtil GUI] 
=====================

Version : v1.0
Auteur  : [big_fury]SiZiOUS a.k.a SiZ!

I) Presentation
---------------

Original readme content :

The purpose of this program is just search ADX(c) samples on files such as
AFS archive or a single file. Extract and convert to WAVE format if desired.

ADX - Sound format used on DreamCast(tm) games,
AFS - Several data types compiled in one archive, ADX is one of formats.

The interal ADXUtil program is the 1.0 version.

* Files extracted of AFS archives are in sequences like as "BOMBER_00000"

* The program uses LFN (long filenames) functions, use the program with
  running Win9X(tm) or compatible system

* Do not distribute illegal data, is dangerous for you !

II) Usage
---------

Very simple, you can add a directory which contains AFS files in one step, drag and
drop files on the window, add a single file and more.

You can right click with your mouse on the window for more options.

Just press Convert when you have your selection ready.

III) Credits
------------

This app was programmed by [big_fury]SiZiOUS (SiZ!). 
It is freeware and can be distributed, if you keep the original package.

Thanks to Jefferson Leandro Ramos Ricci aka Verdi Kasugano
(verdi@kasugano.cjb.net) / Brazil

Enjoy it !!!

[big_fury]SiZiOUS
http://www.sbibuilder.fr.st/

<EOF>