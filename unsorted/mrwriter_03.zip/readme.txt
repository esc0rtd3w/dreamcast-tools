MR Writer 0.3
Created by fackue
http://dchelp.dcemulaion.com

As the name says, it creates MR files from PNG, GIF and BMP images.

What's new?
- fixed "Subscript out of rage" error when uncompressing some MRs

Features?
- Creates MRs
- Displays MRs
- Preview the MR in the license screen
- Supports PNG, BMP, and GIF images

History:
0.2
- forgot to check if the MR fits in normal IP.BIN files

0.1
- initial release

Credits\Thanks:
- kRYPT