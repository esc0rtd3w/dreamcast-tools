In case anyone is interested, I have written a script that can burn most CDI images on Linux. It is based on cdirip 0.6.3 and cdrecord (I use version Cdrecord-Clone 2.01.01a04).

To use the script, just type "burndc-cdi {name-of-CDI-image}" in a shell. You may have to adjust the device specification for the burner in the script. To find the ID of your burner, try

+---------------------------+
| cdrecord dev=ATA -scanbus |
+---------------------------+

or

+-------------------+
| cdrecord -scanbus |
+-------------------+

The script is attached. Make it executable (chmod a+x {filename}).

Use at your own risk ;)

http://www.dcemu.co.uk/vbulletin/showpost.php?p=136724&postcount=5

milksheik