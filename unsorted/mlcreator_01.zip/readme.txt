nxDoom Modlist Creator 0.1
Released by fackue - 10 7, 2006
http://www.consolevision.com/members/dchelp/

A pretty basic modlist creator for nxDoom 2.2 Beta2. The advantages of using
this program to manually making your modlist is it has all the working command
line parameters listed within the program, and organization through a very
simple and basic interface. Yes, it's about 4 years late. Better then never I
suppose.

How the modlist works:
Each mod entry is split in four columns delimited by commas. The first column
is the name of the mod, the second is the original Doom IWAD, thrid is for
supported command line parameters and the fourth is for descriptions. You can
use # in the description to designate a new line.

nxDoom adds the original Doom IWADs in it's modlist automatically along with
any music PWADs which means those entries won't have any special command line
parameters. It's possible to manually add those IWADs to the modlist, allowing
you to use any command line parameters you wish. To prevent nxDoom from
automatically adding those IWADs to the modlist, you can rename them. If you 
don't want to use any command line parameters then leave the filenames as-is
and don't add any entries for just the original IWADs.
Adding a entry for an original IWAD with a music PWAD might look like this:

	Doom 2,DOOM2.WAD,-file DOOM2_XM.WAD -warp 21,Doom 2#Warp to episode 2 level 1

Explanation of Command Line Parameters:
	-avg:		ends game after 20 minutes
	-deh:		loads only DeHacked patches
	-episode:	episode to start at
	-file:		loads PWADs and DeHacked patches
	-loadgame:	saved game to start at
	-skill:		skill level to start at
	-turbo:		increases movement speed
	-warp:		episode and level to start at
	
Credits:
	Sir Robin (Doom icon)
	BlackAura (nxDoom)