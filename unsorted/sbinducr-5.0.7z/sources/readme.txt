             _______         __   ___ __                 __     
            |     __|.-----.|  |.'  _|  |--.-----.-----.|  |_   
            |__     ||  -__||  ||   _|  _  |  _  |  _  ||   _|  
            |_______||_____||__||__| |_____|_____|_____||____|  
                                                    
             __           __                             ______ 
            |__|.-----.--|  |.--.--.----.-----.----.    |    __|
            |  ||     |  _  ||  |  |  __|  -__|   _|    |__    |
            |__||__|__|_____||_____|____|_____|__|      |______|
                                                   				
                      Welcome to Selfboot Inducer 5 !
					  
  Thanks for your download. So you wanna compile/modify/rebuild this program ?
  Keep reading this file to learn how to work with the source code!
  Please keep in mind that source code is released under the GNU GPL 3.
      ___                  _      __  _         
     / _ \___ ___ ________(_)__  / /_(_)__  ___ 
___ / // / -_|_-</ __/ __/ / _ \/ __/ / _ \/ _ \________________________________
   /____/\__/___/\__/_/ /_/ .__/\__/_/\___/_//_/
                         /_/ I. DESCRiPTiON          

  Selfboot Inducer 5 is a Windows program made to build a DreamInducer bootable 
  compilation CD-ROM for your Sega Dreamcast.

  DreamInducer is a Dreamcast program made by DCGrendel allowing you to put 
  multiple homebrew games, emulators, demos or applications onto the same CD. 
  For the history, it was submitted as an entry for the DCEmulation's 
  Programming Contest 2002 Edition.
  
  To use this application, you must have the packages corresponding to the
  application you like, for example "neo4all.sbi" for Neo 4 All emulator from
  our friend Chui. SBI packages can be found on the net. 
  
  If you can't find SBI package, remember that you can use the "SBI Builder" 
  application to build your proper package!
              http://sizious.emunova.net/download/?idsys=2&idcat=3
 
  You can remplace the "Sb!ffy" default theme by your theme, for this, just
  put the "(theme_name).sbt" file in the "packages" directory. Currently, there
  isn't programs to make Selfboot Inducer Themes.

  To learn how to use this program in details, click on the "Help" button
  inside Selfboot Inducer.
  
     _____                _ ___          
    / ___/__  __ _  ___  (_) (_)__  ___ _
___/ /__/ _ \/  ' \/ _ \/ / / / _ \/ _ `/_______________________________________
   \___/\___/_/_/_/ .__/_/_/_/_//_/\_, / II. COMPiLiNG
                 /_/              /___/

  To compile this application, keep reading.
  
  Requirements:
    - JVCL: http://jvcl.delphi-jedi.org/
      I'm using the JVCL 3.45 and JCL 2.3.1 ("JVCL345CompleteJCL231-Build4197").
    - Delphi XE2+
    - The "<sbinducr_root>\sources\bin\Win32\<release_kind>\" directory *MUST*
      contains the "engine" directory with the files:
       	- cdi2nero.exe (converts DiscJuggler CDI to Nero Burning Rom NRG images)
       	- cdi4dc.exe (generates a DiscJuggler CDI image)
        - cdrecord.exe (burn a disc)
        - inducer.sbi (DreamInducer base package)
        - mds4dc.exe (generates a Alcohol 120% Image)
        - mkisofs.exe (generate an ISO image for cdi4dc or mds4dc)
        - scramble.exe (to use KallistiOS scrambled binaries on DreamInducer)
        - wnaspi32.dll (Nero Burning Rom WinASPI drivers for cdrecord)
    - You should put your ".SBI" packages under the 
      "<sbinducr_root>\sources\bin\Win32\<release_kind>\packages\" directory.
		
   Compiling :
     0. Make sure that JVCL is installed.
     1. Open Delphi XE2 (or superior).
     2. Select "File" > "Open a project...".
     3. Select the file "sbinducr.dproj" in the "<sbinducr_root>\sources\src\"
        directory.
     4. On the "Project Manager", right-click on the "sbinducr.exe" node, then
        click "Rebuild".
     5. Enjoy.

  Please send me an e-mail if you release a modified version of my program !
  I'm always happy to see that my work is used.
     _____           ___ __    
    / ___/______ ___/ (_) /____
___/ /__/ __/ -_) _  / / __(_-<_________________________________________________
   \___/_/  \__/\_,_/_/\__/___/ III. CREDiTS
                         
  This application was written by [big_fury]SiZiOUS; just call me "SiZiOUS" or
  "SiZ!". The "big_fury" prefix is my (very) older nickname, the first I taken,
  it's a reference of the "Big Fury Monster" card from Magic The Gathering 
  Ungled Edition.
  
  Credits list:
    DCGrendel - DreamInducer program
    burnerO - Original Selfboot Inducer at the lastest v4.0
    Curtiss Grymala - For the original tutorial, included in Selfboot Inducer 4
    fackue - Awesome tools and source codes that helped me on some minor points
    VasiliyRS - Very useful beta testing
    kRYPT_ - MR compress/decompression source code in Delphi
    ADK/Napalm - png2mr / logoinsert source codes in C
    Marcus Comstedt - For selfbooting instruction...
    CDRTools Contributors - You know why
    UPX - Because Delphi executables are sooo big...
    patorjk.com - For the ASCII ART Text Generation... making readme files cool!
    _____          __           __ 
   / ___/__  ___  / /____ _____/ /_
__/ /__/ _ \/ _ \/ __/ _ `/ __/ __/_____________________________________________
  \___/\___/_//_/\__/\_,_/\__/\__/ IV. CONTACT
                                 
  Wanna contact me ? Check it out:

  Web        :    http://www.sizious.com/
  Twitter    :    http://twitter.com/sizious/
  Facebook   :    http://facebook.com/sizious/
  Mail       :    sizious (at) gmail (d0t) com

__[ -eof- ]_____________________________________________________________________
