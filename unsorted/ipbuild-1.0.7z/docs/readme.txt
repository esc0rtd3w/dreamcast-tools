  [big_fury]
  888888888    8888  888888888888  8888     888888888     8888      8888   888888888
8888888888888  8888  888888888888  8888   8888888888888   8888      8888 8888888888888
8888     8888              88888         8888       8888  8888      8888 8888     8888
888888888      8888      888888    8888 8888         8888 8888      8888 888888888
  8888888888   8888     88888      8888 8888         8888 8888      8888   88888888888
       888888  8888   88888        8888 8888         8888 8888      8888         888888
8888      8888 8888  88888         8888  8888       8888  8888      8888 8888      8888
8888888888888  8888 88888888888888 8888   8888888888888    888888888888  8888888888888
  8888888888   8888 88888888888888 8888     888888888       8888888888     8888888888

IP.BIN CREATOR
==============

Version : v1.0
Autor   : [big_fury]SiZiOUS a.k.a SiZ!
Website : http://www.sbibuilder.fr.st/

I) Presentation : 
-----------------

Hello everyone! This program create a custom IP.BIN for SEGA Dreamcast. 
You can also add a custom logo, inside the IP.BIN.

II) Use : 
---------

Run the software. Follow the steps. You don't need any tutorial for this app.
It very simple. Logos must be 320x90 maximum with 128 colors, in the MR format.
Don't be afraid by the MR format, this program convert it from any image type
(common like BMP, GIF, JPG and PNG).

You can use preset if you want to keep your company name or something like that.

III) Credits : 
--------------

This app was programmed by [big_fury]SiZiOUS (SiZ!). 
It is freeware and can be distributed, if you keep the original package.

Enjoy it !!!

[big_fury]SiZiOUS
http://www.sbibuilder.fr.st/

<EOF>