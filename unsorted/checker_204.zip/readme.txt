Bin Checker
Created by fackue
http://dchelp.dcemulation.org

Detects the type of binary a Dreamcast binary is.

What's new in 2.0.4:
- Couple small changes
- Fixed Check for Update
- Source cleanup

Features:
- detects scrambled and unscrambled binaries
- detects Katana, WinCE and Naomi binaries
- ability to manually identify a binary (converting purposes)
- scrambling and unscrambling
- ELF to BIN
- check for updates

Incompatible with:
- Beats of Rage
- LinuxDC
- dc-load

Thanks (in no order):
- Marcus Comstedt (scramble)

History:
2.0.3a
- fixed: non .bin files weren't saved with their original extension
- fixed: converted ELF files were saved with the "elf" extension

2.0.3
- fixed Invalid procedure call or argument error with files sent through the
command line
- file extensions are kept as they were (case sensitive)
- uses all the same instance
- binary converted successfully check
- context menus removed (use SendTo instead)
- code cleanup
- drag and dropping
- SREC detection

2.0.2
- convert enabled for Katana, WinCE and Naomi binaries
- checking for new version
- manual binary identification
- doesn't try to convert if scanned binary was deleted

2.0.1b
- changed the initial save folder

2.0.1a
- fixed strange disabled Convert button

2.0.1
- reworked the context menu support
- MinGW compiled sh-elf-objcopy
- improved scanning code (should be faster)
- true ELF binary detection
- ablility to toggle "-R .stack"
- detects Katana binaries
- detects Naomi binaries
- detects WinCE binaries
- support for FISA, VMUFrog
- lots of changes and improvments

2.0
- progress bar
- non-dependent on COMDLG32.OCX
- completely rewritten
- file size now in bytes, KB, or MB
- IP.BIN loading error
- non-BIN file loading error

1.5
- ELF support (and right-click support)
 
1.4
- right-click shell integration
- support for older demos
- filename saving changed

1.3
- scan button removed (automatically scanned)
- cancel button in file dialog works correctly
- dcscram is a must to convert, but not to open program
- file naming change (original file name kept)

1.2
- support for DreamSNES
- support for NetBSD / DC

1.1b
- various bug fixes (uppercase files)

1.1
- new GUI (no more message boxes)
- error if an IP.BIN loaded

1.beta5
- scrambling / unscrambling now supported (!)

1.beta4
- support for a lot more older libdream apps
- errors is a file is not a BIN

1.beta3
- support for a lot of older libdream apps

1.beta2
- fixed the 2 message box problem
- support for a few older apps
- shortcut keys

1.beta1
- support for a lot more BINs
- 2 message boxes for BIN result (annoying)

1.0
- initial release