#include <string.h>
#include "menu.h"
#include <stdio.h>

extern void go(unsigned int addr);

int dc_main() {
	unsigned char *ptr = (unsigned char*)(MNUBASE);
        
	memcpy(ptr,menu,sizeof(menu));
	if(memcmp(ptr,menu,sizeof(menu))) return 0;

	go(MNUBASE);
	
	return 0;
}
