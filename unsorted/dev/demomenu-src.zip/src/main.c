/* Grendel's Dreamcast Demo Loader   v1.3 *
 ******************************************
 * based on works by Dan Potter (vmuload) *
 * Andrew Kieschnick (dcload)             *
 * and who ever wrote scramble.c (marcus?)*
 ******************************************
 * Please read COPYING for details        *
 ******************************************/


/* global includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* local includes */
#include "dream.h"
#include "config.h"
#include "menufont.h"

/* defines */
#define RGBLONG(r,g,b) (((r>>3)<<11)|((g>>2)<<5)|(b>>3))

#define MAXCHUNK   	(2048*1024) // 2MB Chunks

#define L1_CACHE_BYTES 32
#define CACHE_IC_ADDRESS_ARRAY  0xf0000000
#define CACHE_IC_ENTRY_MASK	0x1fe0

struct __large_struct { uint32 buf[100]; };
#define __m(x) (*(struct __large_struct *)(x))


/* structures */
struct {
	unsigned short back;	 // Background
	unsigned short text;	 // Foreground
	unsigned short selected; // Selected items
	unsigned short mouse;	 // Duh :+]
} colour;

struct {
	char	desc[40];	// displayed description
	char	name[512];	// full path to file
	long	size;		// size of file (number)
} file[512];

struct {
	char	name[512];
} pdir[512];

/* external references */
extern void play_s3m(char *song, unsigned long sz);
extern void go(unsigned int addr);

/* references to be redefined later */
int dc_main();

// global variables
uint16 ents=0, prevdir=0, scrambled=1;
int16 mousex=0, mousey=0, mousedx=0, mousedy=0;
static unsigned int seed;

unsigned long mousebuf[512];

void storebuf(int mx, int my) {
	int x, y, i=0;
        unsigned short * in = vram_s + my * 640 + mx;

        for (y=0; y<8; y++) {
                for (x=0; x<8; x++) {
			mousebuf[i++]=in[x];
		}
		in += 640; 
	}
}

void restorebuf(int mx, int my) {
	int x, y, i=0;
        unsigned short * out = vram_s + my * 640 + mx;

        for (y=0; y<8; y++) {
                for (x=0; x<8; x++) {
			out[x]=mousebuf[i++];
		}
		out += 640; 
	}
}

char *ltoa(long src) {
	char buf[10];
	sprintf(buf,"%li",src);
	return buf;
}

void alert(char *msg) {
	int box_w, box_h, box_x, box_y;
	int x,y;

	box_w = strlen(msg) + 3;
	box_h = 6;
	box_x = (VID_S_X-box_w)/2;
	box_y = (VID_S_Y-4)/2;

	for(x=box_x;x<=(box_w+box_x);x++) drawc(x*8,box_y*8,colour.text,0xdb);
	for(x=box_x;x<=(box_w+box_x);x++) drawc(x*8,(box_y+box_h)*8,colour.text,0xdb);
	for(y=box_y;y<=(box_h+box_y);y++) drawc(box_x*8,y*8,colour.text,0xdb);
	for(y=box_y;y<=(box_h+box_y);y++) drawc((box_x+box_w)*8,y*8,colour.text,0xdb);

	for(y=box_y+1;y<=(box_h+box_y)-1;y++)
	for(x=box_x+1;x<=(box_w+box_x)-1;x++)
		drawc(x*8,y*8,colour.back,0xdb);

	draw_printf((box_x+2)*8,(box_y+2)*8,colour.text,"%s",msg);
	serial_printf("%s\r\n",msg);

	return;
}

void vid_set(unsigned short pixel) {
	int x,y;
	for(x=0;x<VID_S_X;x++)
		for(y=0;y<VID_S_Y;y++) {
			drawc(VID_O_X+(x*8),VID_O_Y+(y*8),pixel,219);
		}
}

static void flush_icache_range(uint32 start, uint32 end) {
	uint32 addr, data, v;
	end += start;
	start &= ~(L1_CACHE_BYTES-1);
	for (v=start; v<end; v+=L1_CACHE_BYTES) {
		/* Write back O Cache */
			asm volatile("ocbwb %0"
					: /* no output */
					: "m" (__m(v)));
			/* Invalidate I Cache */
			//addr = CACHE_IC_ADDRESS_ARRAY |
			//      (v & CACHE_IC_ENTRY_MASK) | 0x8 /* A-bit */;
			addr = CACHE_IC_ADDRESS_ARRAY |
				(v & CACHE_IC_ENTRY_MASK);
			data = (v & 0xfffffc00);        /* Valid = 0 */
			*((volatile uint32*)addr) = data;
	}
}

void call_prog() {
	go(0x8c010000);
}

void my_srand(unsigned int n) {
	seed = n & 0xffff;
}

unsigned int my_rand() {
	seed = (seed * 2109 + 9273) & 0x7fff;
	return (seed + 0xc000) & 0xffff;
}

void load(int fd, unsigned char *ptr, unsigned long sz) {
	if(iso_read(fd, ptr, sz) != sz) {
		serial_printf("Read error!\n");
		dc_main();
	}
}

void ram_chunk(unsigned char *scratch, unsigned char *ptr, unsigned long sz) {
        static int idx[MAXCHUNK/32];
        int i;

	/* Convert chunk size to number of slices */
	sz /= 32;

	/* Initialize index table with unity,
	 *      so that each slice gets loaded exactly once */
	for(i = 0; i < sz; i++)
	idx[i] = i;

	for(i = sz-1; i >= 0; --i) {
	        
	        /* Select a replacement index */
	        int x = (my_rand() * i) >> 16;  

		/* Swap */
		int tmp = idx[i];

		idx[i] = idx[x];
		idx[x] = tmp;   
		/* Load resulting slice */
		memcpy(ptr+32*idx[i], scratch, 32);
		scratch += 32;
	}
}

void load_file(int fd, unsigned char *ptr, unsigned long filesz)
{
  unsigned long chunksz, i;
  my_srand(filesz);

  /* Descramble 2 meg blocks for as long as possible, then
   *      gradually reduce the window down to 32 bytes (1 slice) */
  for(chunksz = MAXCHUNK; chunksz >= 32; chunksz >>= 1)
    while(filesz >= chunksz)
      {
	uint8 *scratchpad = (uint8 *)SCRATCHPAD+512;

	for(i=0;i<chunksz;i+=32) {
		load(fd, scratchpad, 32);
		scratchpad+=32;
		drawc(216+((i*200)/chunksz),256,colour.selected,0xdb);
	}
	scratchpad = (uint8 *)SCRATCHPAD+512;
        ram_chunk(scratchpad, ptr, chunksz);
	filesz -= chunksz;
	ptr += chunksz;
      }
  /* Load final incomplete slice */
  if(filesz>0)
    load(fd, ptr, filesz);
}

void read_file_s(char *filename) {
  unsigned char *ptr = NULL;
  unsigned long sz = 0;
  int fd, i;
		
  fd = iso_open(filename, O_RDONLY);
  if(fd < 0)
    {
      serial_printf("Can't open \"%s\".\n", filename);
      dc_main();
    }

  for (i=0;i<ents;i++)
    if (file[i].name==filename)
      {
        sz=file[i].size;
      }

  ptr = (uint8*)(0x8c010000);
  load_file(fd, ptr, sz);
  iso_close(fd);
}

void read_file_u(char *filename) {
  unsigned char *ptr = NULL;
  unsigned long sz = 0, sze = 0;
  int fd, i;
		
  fd = iso_open(filename, O_RDONLY);
  if(fd < 0)
    {
      serial_printf("Can't open \"%s\".\n", filename);
      dc_main();
    }

  for (i=0;i<ents;i++)
    if (file[i].name==filename)
      {
        sz=file[i].size;
        sze=file[i].size;
      }

  i = 0;
  ptr = (uint8*)(0x8c010000);

  while(sz>32) {
    load(fd, ptr, 32);
    drawc(216+((i*200)/sze),256,colour.selected,0xdb);

    i+=32;
    ptr+=32;
    sz-=32;
  }

  if(sz>0)
    load(fd, ptr, sz);

  iso_close(fd);
}


char *menu(char *dirroot) {
	int i=0, y=0, x=0, moved=0, run=0, d, u;
	dirent_t *de;
	mouse_cond_t mcond;
	cont_cond_t cond;
	uint8 mcont=0;
	uint8 mmouse=0;
	char *t_filename;
	int t_filesize;
	
	ents=0;

	for(x=0;x<VID_S_X;x++)
		for(y=4;y<VID_S_Y;y++) {
			drawc(VID_O_X+(x*8),VID_O_Y+(y*8),colour.back,219);
		}
        for(x=0;x<VID_S_X;x++)
		for(y=0;y<4;y++) {
			drawc(VID_O_X+(x*8),VID_O_Y+(y*8),colour.text,mnubkg[y*VID_S_X+x]);
		}

	// Clear out the buffers so we don't get any stray
	// buttons floating around :)
	maple_rescan_bus(1);
	mcont = maple_controller_addr();
	mmouse = maple_mouse_addr();

	if (mmouse>0)
	    if (mouse_get_cond(mmouse, &mcond) < 0) return dirroot;
	if (mcont>0)
	    if (cont_get_cond(mcont, &cond) < 0) return dirroot;

	if (scrambled==1) draw_printf(VID_O_X,(VID_O_Y+(8*(VID_S_Y-1))),colour.text,"SL");
	if (scrambled==0) draw_printf(VID_O_X,(VID_O_Y+(8*(VID_S_Y-1))),colour.back,"SL");
	
	sprintf(file[i].name,"%s",pdir[prevdir].name);
	sprintf(file[i].desc,"Parent Directory");
	file[i].size=-1;
	i++;

	for(u=0;u<=1;u++) {

		/* read and print the root directory */
		d = iso_open(dirroot, O_RDONLY | O_DIR);

		while (d<0) {
			alert("Please insert a CD-ROM into the reader.");
			timer_sleep(500);
			sprintf(dirroot,"/");
			d = iso_open(dirroot, O_RDONLY | O_DIR);
			if(d>0)
			  for(x=0;x<VID_S_X;x++)
			   for(y=26;y<34;y++) {
			    drawc(VID_O_X+(x*8),VID_O_Y+(y*8),colour.back,219);
			   }
		}

		while ( (de=iso_readdir(d)) ) {
				strcpy(file[i].desc,de->name);
				if((de->size<0) && (u==0)) {
					sprintf(file[i].name,"%s%s/",dirroot,de->name);
					file[i].size=de->size;
					serial_flush();
					i++;
				}
				if((de->size>=0) && (u==1)) {
					sprintf(file[i].name,"%s%s",dirroot,de->name);
					file[i].size=de->size;
					serial_flush();
					i++;
				}
		}

		ents=i;
		iso_close(d);

	}

	if (ents > 54) ents=54;

	draw_printf(VID_O_X,VID_O_Y+((8*5)/2),colour.text," Filename                          Size ");

	for(i=0;i<ents;i++) {
	    draw_printf(VID_O_X+8,VID_O_Y+(i*8+(8*9/2)), \
		colour.text,"%s", file[i].desc);
	  if(file[i].size<0)
	    draw_printf((39*8)-(2*8), \
		VID_O_Y+(i*8+(8*9/2)), \
		colour.text,"%c%c",25,26);
	  if(file[i].size>=0)
	    draw_printf((39*8)-(strlen(ltoa(file[i].size))*8), \
		VID_O_Y+(i*8+(8*9/2)), \
		colour.text,"%li",file[i].size);
	}

	i=0;x=0;

//	restorebuf(mousex,mousey);

	draw_printf(VID_O_X+8, VID_O_Y+(8*9/2), \
	    colour.selected,"%s", file[0].desc);

	storebuf(mousex,mousey);
	drawc(mousex,mousey,colour.back,24);
	drawc(mousex,mousey,colour.mouse,23);

	while(1) {
		timer_sleep(20);

		if (mcont<=0){
			maple_rescan_bus(1);
			mcont = maple_controller_addr();
		} else if (cont_get_cond(mcont, &cond) < 0) {
			maple_rescan_bus(1);
                        mcont = maple_controller_addr();
		}

		if (mmouse<=0){
			maple_rescan_bus(1);
			mmouse = maple_mouse_addr();
		} else if (mouse_get_cond(mmouse, &mcond) < 0) {
			maple_rescan_bus(1);
                        mmouse = maple_mouse_addr();
		}

		mousedy=0; mousedx=0;

		if (mmouse && (mcond.dx || mcond.dy)) {
			mousedy+=mcond.dy;
			mousedx+=mcond.dx;
		}

		if (mcont && (cond.joyx || cond.joyy)) {
			mousedy+=(cond.joyy-128)/16;
			mousedx+=(cond.joyx-128)/16;
		}

		if (mcont && !(cond.buttons & CONT_DPAD_UP))    mousedy-=2;
		if (mcont && !(cond.buttons & CONT_DPAD_DOWN))  mousedy+=2;
		if (mcont && !(cond.buttons & CONT_DPAD_LEFT))  mousedx-=2;
		if (mcont && !(cond.buttons & CONT_DPAD_RIGHT)) mousedx+=2;

		if (mousedx!=0 || mousedy!=0) {
			restorebuf(mousex,mousey);


			mousex += mousedx;
			mousey += mousedy;

			if (mousex<0) mousex=0;
			if (mousey<0) mousey=0;
			
			if (mousex>639-8) mousex=639-8;
			if (mousey>479-8) mousey=479-8;

			storebuf(mousex,mousey);

			drawc(mousex,mousey,colour.back,24);
			drawc(mousex,mousey,colour.mouse,23);
			for(y=0;y<ents;y++)
			    if (((VID_O_Y+(y*8+(8*9/2)))<mousey) && ((VID_O_Y+(y*8+(8*11/2)))>mousey))
				if(y!=x) { 
				    moved=1;
				    i=y;
				}
		}

		if (moved) {

			restorebuf(mousex,mousey);

			draw_printf(VID_O_X+8,VID_O_Y+(x*8+(8*9/2)), \
			    colour.text,"%s", file[x].desc);
			draw_printf(VID_O_X+8,VID_O_Y+(i*8+(8*9/2)), \
			    colour.selected,"%s", file[i].desc);

			storebuf(mousex,mousey);

			drawc(mousex,mousey,colour.back,24);
			drawc(mousex,mousey,colour.mouse,22);

			x=i;
			moved=0;
		}

		if ((mmouse && !(mcond.buttons & MOUSE_RIGHTBUTTON)) ||
		    (mcont && !(cond.buttons & CONT_B))) {
			dirroot="/";
			break;
		}

		if ((mmouse && mcond.dz) ||
		    (mcont && !(cond.buttons & CONT_Y))) {
			if (scrambled==0) {
				scrambled=1;
			} else {
				scrambled=0;
			}
			if (scrambled==1) draw_printf(VID_O_X,VID_O_Y+(8*(VID_S_Y-1)),colour.text,"SL");
			if (scrambled==0) draw_printf(VID_O_X,VID_O_Y+(8*(VID_S_Y-1)),colour.back,"SL");
			if (!(cond.buttons & CONT_Y)) while(!(cond.buttons & CONT_Y)) {
				if (mcont<=0){
					maple_rescan_bus(1);
					mcont = maple_controller_addr();
				} else if (cont_get_cond(mcont, &cond) < 0) {
					maple_rescan_bus(1);
					mcont = maple_controller_addr();
				}
			}
			   		
		}

		if ((mmouse && !(mcond.buttons & MOUSE_LEFTBUTTON)) ||
		    (mcont && !(cond.buttons & CONT_A)) ||
		    (mcont && !(cond.buttons & CONT_START))) {
			run=1;
			break;
		}

		if(CABLE!=vid_check_cable()) {
			init_video(0);
		}
	}
	
	if(!run) return dirroot;
	
	for(x=0;x<80;x++)
		for(y=4;y<VID_S_Y-8;y++) {
			drawc(VID_O_X+(x*8),VID_O_Y+(y*8),colour.back,219);
		}


	t_filename=file[i].name;
	t_filesize=file[i].size;

        if (t_filesize<0) {
		if(!strcmp(pdir[prevdir].name,t_filename)) {
			prevdir--;
			return t_filename;
		}
		strcpy(pdir[++prevdir].name,dirroot);
        	return t_filename;
        }

	if ((!strcmp(&t_filename[strlen(t_filename)-3],"bin"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"BIN"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"sh4"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"SH4"))) {

		alert("Please Wait, loading program...");

		if(scrambled==1) read_file_s(t_filename);
	      	if(scrambled==0) read_file_u(t_filename);

		flush_icache_range(0x8c010000, t_filesize+2048);
		alert("Cache flushed, executing program.");
		call_prog();
	}
	
	if ((!strcmp(&t_filename[strlen(t_filename)-3],"s3m"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"S3M"))) {
		uint8 *ptr = (uint8*)(0x8c010000);

		alert("Please Wait, loading file...");

		read_file_u(t_filename);
		play_s3m(ptr,t_filesize);

		timer_sleep(50);
	}

	if ((!strcmp(&t_filename[strlen(t_filename)-3],"MP3"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"mp3"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"MP2"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"mp2"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"MP1"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"mp1"))) {
//		alert("Please Wait, loading file...");
		alert("Cannot play MPG123 audio yet.");
		timer_sleep(1500);
	}

	if ((!strcmp(&t_filename[strlen(t_filename)-3],"MPG"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"mpg"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"SFD"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"sfd"))) {
//		alert("Please Wait, loading file...");
		alert("Cannot play MPG/SFD movies yet.");
		timer_sleep(1500);
	}

	if ((!strcmp(&t_filename[strlen(t_filename)-3],"ADX"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"adx"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"AFS"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"afs"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"SFA"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"sfa"))) {
//		alert("Please Wait, loading file...");
		alert("Cannot play ADX/SFA audio yet.");
		timer_sleep(1500);
	}

	if ((!strcmp(&t_filename[strlen(t_filename)-3],"JPG"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"jpg"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"GIF"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"gif"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"XPM"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"xpm"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"PCX"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"pcx"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"PNG"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"png"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"BMP"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"bmp"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"PVR"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"pvr"))) {
//		alert("Please Wait, loading file...");
		alert("Images are not yet supported.");
		timer_sleep(1500);
	}

	if ((!strcmp(&t_filename[strlen(t_filename)-3],"EXE"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"exe"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"COM"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"com"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"BAT"))||
	    (!strcmp(&t_filename[strlen(t_filename)-3],"bat"))) {
//		alert("Please Wait, loading file...");
		alert("This type of executable is unsupported.");
		timer_sleep(1500);
	}


	return dirroot;	
}

int dc_main() {
	char *dirroot = (char *)SCRATCHPAD;
	
#ifndef DEBUG
	serial_disable();
#endif
	my_init(); // My replacement for dc_setup

        colour.text=RGBLONG(0,144,127);
        colour.back=RGBLONG(0,0,0);
        colour.selected=RGBLONG(0,127,255);
        colour.mouse=RGBLONG(255,255,255);

	vid_set(colour.back);
	font_set(fontdata_8x8,8);

        sprintf(dirroot,"/");
	strcpy(pdir[0].name,dirroot);

	while(1)
	  strcpy(dirroot,menu(dirroot));

	return 0;
}

