
/*
 * Debug (enable serial port?)
 */

//#define DEBUG

/***********************************
 * DO NOT EDIT BELOW THIS LINE!!!! *
 ***********************************/

#define	draw_printf	draw_stringf
#define	drawc		draw_char

int VID_O_X=0, VID_O_Y=0, VID_S_X=80, VID_S_Y=60, TV_MODE, CABLE;

unsigned char mnubkg[512];

void set_bkg() {
  sprintf(mnubkg,"%s%s%s%s%s",
   " Grendel's Dreamcast Demo Loader  v1.4-BETA-0                                   ",
   "________________________________________________________________________________",
   "                                                                                ",
   "________________________________________________________________________________",
   "                                                                                "
  );
};

void init_video(int clear) {
	CABLE=vid_check_cable();
	vid_init(CABLE, DM_640x480, PM_RGB565);
	if(clear) vid_clear(0,0,0);
	set_bkg();
}

void my_init() {
        serial_init(57600);	// Initialize serial port
	init_video(1);		// Initialize video
	snd_init();		// Clear SRAM & Reset SPU
	cdrom_init();		// Enable the GD-ROM
	iso_init();		// Start the filesystem
	maple_init(1);		// Load up the controllers
	timer_init();		// Setup the system timers
}

