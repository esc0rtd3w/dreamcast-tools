#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dream.h"
#include "s3mplay.h"

extern void alert(char *msg);

/* This is sort of an unorthodox way of using the SPU ^_^;; but it's
   how the S3M player works right now. */
volatile unsigned long *snd_dbg = (unsigned long*)0xa080ffc0;
void copy_s3m(char *song, int len) {
	snd_init();
	snd_load(song, 0x10000, len);

	/* Switch channels to mono if uncommented */
	/* snd_dbg[1] = 1; */

	vid_clear(0,0,0);
	
	alert("Load OK, starting ARM");
	snd_load_arm(s3mplay, sizeof(s3mplay));

	while (*snd_dbg != 3)
		;

	while (*snd_dbg == 3)
		;
}

void wait_stop() {
	uint8 mcont=0;
	uint8 mmouse=0;
	cont_cond_t cond;
	mouse_cond_t mcond;

	vid_clear(0,0,0);

	alert("Press A / Left Click to stop.");

	maple_rescan_bus(1);

	mcont = maple_controller_addr();
	mmouse = maple_mouse_addr();

	if (cont_get_cond(mcont, &cond) < 0) mcont=0;
	if (mouse_get_cond(mmouse, &mcond) < 0) mmouse=0;

	while (1) {
		if (mcont<=0){
			maple_rescan_bus(1);
			mcont = maple_controller_addr();
		} else if (cont_get_cond(mcont, &cond) < 0) {
			maple_rescan_bus(1);
			mcont = maple_controller_addr();
		}

		if (mmouse<=0){
			maple_rescan_bus(1);
			mmouse = maple_mouse_addr();
		} else if (mouse_get_cond(mmouse, &mcond) < 0) {
			maple_rescan_bus(1);
			mmouse = maple_mouse_addr();
		}
		
                if (mmouse>0)
		    if (!(mcond.buttons & MOUSE_LEFTBUTTON)) {
			return;
		}  

		if (mcont>0)
		    if (!(cond.buttons & CONT_X)) {
			return;
		}
		
		sleep(10);
	}
}

void play_s3m(char *song, unsigned long sz) {
	/* Status message */
	alert("Loading file into sound ram...");

	/* Start a song playing */
	copy_s3m(song, sz);

	/* Wait */
	wait_stop();

	/* Quit snd_init() is much better than snd_stop_arm() */
	snd_init();

	return;
}
