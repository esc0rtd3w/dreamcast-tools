/* Shuttle space for code beeing moved from DreamSNES. Should be
 *  treated as one big FIXME. 
 */
#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

void show_file_error(struct font *font);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
