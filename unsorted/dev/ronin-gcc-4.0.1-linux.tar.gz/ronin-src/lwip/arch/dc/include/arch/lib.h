#ifndef __LIB_H__
#define __LIB_H__

#include <string.h>

/* Avoid name conflict in arp.c */
#define ctime lwip_ctime

#endif /* __LIB_H__ */
