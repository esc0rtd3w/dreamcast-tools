#ifndef __BBAIF_H__
#define __BBAIF_H__

#include "lwip/netif.h"

void bbaif_init(struct netif *netif);

#endif /* __BBAIF_H__ */
