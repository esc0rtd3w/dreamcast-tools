#include "video.h"

struct _fb_devconfig fb_devconfig;
struct _dispvar dispvar;

