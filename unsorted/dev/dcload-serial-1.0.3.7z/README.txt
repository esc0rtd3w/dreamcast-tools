
---NOTICE!---

This ready-to-burn image was created by The Gypsy for distribution
from www.boob.co.uk.  It is meant for those unable (or unwilling to
take the time) to create a bootable disc from the original
distribution.  You should be able to just burn this image and boot it
in your DC without any further work on your part.  The Gypsy is not
otherwise associated with this project (except for a minor win32
bugfix as indicated in the Credits/Changelog).

---Original README follows---

dcload 1.0.3 - a Dreamcast serial loader by <andrewk@napalm-x.com>

Features

* Compressed binary transfers (dc-tool supports loading elf, srec, and bin)
* PC I/O (read, write, etc to PC)
* Exception handler

Building

1. Edit Makefile.cfg for your system, and then run make

Installation

1. PC - run make install (installs dc-tool)
2. DC
   a. cd make-cd, edit Makefile, insert blank cd-r, run make
   b. take target-src/1st_read/1st_read.bin and stuff it on a cd yourself
      (please use the IP.BIN from the make-cd directory if you are going
       to distribute either cds or cd images)

Testing

1. cd example-src
2. dc-tool -x console-test.bin (tests some PC I/O)
   (or dc-tool -x console-test, now that dc-tool can load ELF)
3. dc-tool -x exception-test.bin (generates an exception)
   (or dc-tool -x exception-test, now that dc-tool can load ELF)

Notes

* Tested systems: Debian GNU/Linux 2.2
* 115200 works fine for me. Apparently it doesn't for some people. 
* As of 1.0.3, serial speed is changed at runtime rather than compile time. 
* There is now a -e option that will enable an alternate 115200 (which 
  doesn't work for me). If it works for you, please email 
  andrewk@napalm-x.com, especially if it works better than the default 115200.
* Due to the shitty way I wrote some of dc-tool, it won't work on a big-endian 
  system without some modification, sorry. I might get around to fixing that
  eventually.
* Patches and improvements are welcome.

Credits
* Minilzo was written by Markus Oberhumer
* There are some various files from newlib-1.8.2 here, and video.s was written 
  by Marcus Comstedt.
* win32 porting and implementation of -t by Florian 'Proff' Schulze
* bugfix and implementation of -b by The Gypsy
* fixes for cygwin by Florian 'Proff' Schulze
