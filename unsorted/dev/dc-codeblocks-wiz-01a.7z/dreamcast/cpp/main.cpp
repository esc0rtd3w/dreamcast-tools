#include <kos.h>
#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    cout << "\nHello world!\n" << endl;
    return 0;
}
