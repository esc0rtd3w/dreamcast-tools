Run install.bat to copy the SDL & SDL Mixer header and libs to Code::Blocks
then use the SDL & SDL Mixer DLLs in 'sdl-bin' to run Wolf4SDL after it has
been compiled.

- dcbasic