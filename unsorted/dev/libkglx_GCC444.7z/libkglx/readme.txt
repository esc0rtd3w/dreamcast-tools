KGL-X for the DC + KOS 1.2.0/1.3.x

(c) 2002-2005 Heinrich Tillack <http://a128.ch9.de>

released under KOS License.

Please read "README.KOS" for the full details.


WHAT IS KGL-X?
---------------

KGL-X is based on the published OpenGL� API, but it is not an implementation
which is certifed or licensed by Silicon Graphics, Inc. under the OpenGL� API.

And, KGL-X is a derived version of KGL which is part of KallistiOS 1.1.9
(c) 2001-2002 by Dan Potter etc. pp. and libgl (c) 2002 by Bero.

-------
OpenGL� is a registered trademark of Silicon Graphics, Inc.