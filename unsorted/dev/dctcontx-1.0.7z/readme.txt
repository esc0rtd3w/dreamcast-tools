
   [big_fury]
  888888888    8888  888888888888  8888     888888888     8888      8888   888888888
8888888888888  8888  888888888888  8888   8888888888888   8888      8888 8888888888888
8888     8888              88888         8888       8888  8888      8888 8888     8888
888888888      8888      888888    8888 8888         8888 8888      8888 888888888
  8888888888   8888     88888      8888 8888         8888 8888      8888   88888888888
       888888  8888   88888        8888 8888         8888 8888      8888         888888
8888      8888 8888  88888         8888  8888       8888  8888      8888 8888      8888
8888888888888  8888 88888888888888 8888   8888888888888    888888888888  8888888888888
  8888888888   8888 88888888888888 8888     888888888       8888888888     8888888888

*********************
* TURBO DC-TOOL GUI *
*********************

(C)reated in 2004-2005 
by [big_fury]SiZiOUS



I) What's it ?
--------------

TURBO DC-TOOL GUI is a small app which allows upload file to the Dreamcast while using 
right-click context menu on a file. 

Much code comes from the DC-TOOL GUI app, the result that this application is rather stable.

This application isn't for the development. Prefer original DC-TOOL GUI if you wish to 
make some. This application is quickly (a right-click then Upload and it's finished).

You must have the BINCHECK.DLL and the DCTOOL.DLL (from DC-TOOL GUI) in the same dir of the app.

II) Use
-------

Double-Click on the app. If you want to add a context menu to the ELF and BIN files, go to
Options and Select 'Include this app in the context menu'.

Don't move the EXE after doing this !

The use is very simple.

III) Credits
------------

Thanks to all DC communauty, ADK Napalm for DC-TOOL and Phidels.Com.


[big_fury]SiZiOUS
http://www.sbibuilder.fr.st/