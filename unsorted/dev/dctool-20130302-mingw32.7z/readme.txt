		   
               S  i  Z  i  O  U  S    P  R  E  S  E  N  T  S  :
           ___                         ___                         ___  
          (   )                       (   )                       (   ) 
        .-.| |    .--.                 | |_       .--.     .--.    | |  
       /   \ |   /    \               (   __)    /    \   /    \   | |  
      |  .-. |  |  .-. ;    .------.   | |      |  .-. ; |  .-. ;  | |  
      | |  | |  |  |(___)  (________)  | | ___  | |  | | | |  | |  | |  
      | |  | |  |  |                   | |(   ) | |  | | | |  | |  | |  
      | |  | |  |  | ___               | | | |  | |  | | | |  | |  | |  
      | '  | |  |  '(   )              | ' | |  | '  | | | '  | |  | |  
      ' `-'  /  '  `-' |               ' `-' ;  '  `-' / '  `-' /  | |  
       `.__,'    `.__,'                 `.__.    `.__.'   `.__.'  (___)

      DC-TOOL-SERIAL 1.0.4 / DC-TOOL-IP 1.0.5 MinGW Binaries for Windows
      ___                  _      __  _         
     / _ \___ ___ ________(_)__  / /_(_)__  ___ 
___ / // / -_|_-</ __/ __/ / _ \/ __/ / _ \/ _ \_______________________________
   /____/\__/___/\__/_/ /_/ .__/\__/_/\___/_//_/
                         /_/ I. DESCRiPTiON     

  This package contains the lastest dc-tool-serial and dc-tool-ip binaries for 
  Windows, compiled under MinGW the March 2, 2013.

  Using MinGW is better than Cygwin because there is no need for a POSIX 
  emulator. The provided binaries are seen by Windows as native 
  binaries.

  dc-tool-serial is the v1.0.4 and dc-tool-ip the v1.0.5.
  Complete changelogs are available on the original Git repository.

  In order to do use these binaries, you'll need the proper dc-load disc
  and run it on your Dreamcast.
     _____                _ ___          
    / ___/__  __ _  ___  (_) (_)__  ___ _
___/ /__/ _ \/  ' \/ _ \/ / / / _ \/ _ `/______________________________________
   \___/\___/_/_/_/ .__/_/_/_/_//_/\_, /                                         
   II. COMPiLiNG /_/              /___/  

  The source was retrieved from the official Git repository:
            git://cadcdev.git.sourceforge.net/gitroot/cadcdev/cadcdev

  The complete MinGW packages list used for compiling this release is:
     - binutils-2.21.1.tar.bz2
     - gcc-core-4.5.2.tar.bz2
     - gcc-g++-4.5.2.tar.bz2
     - gcc-objc-4.5.2.tar.bz2
     - gmp-5.0.2.tar.bz2
     - libiconv-1.9.2-1-bin.zip
     - libiconv-1.9.2-1-lib.zip
     - mingw-get-inst-20110802.exe
     - mpc-0.8.2.tar.gz
     - mpfr-2.4.2.zip
     - newlib-1.19.0.tar.gz
     - wget-1.9.1-mingwPORT.tar.bz2

  The "src" folder included in this package contains the modified source code
  in order to compile under MinGW. Several adjustements were needed to do that.
  Some code patching/completion was done in the "sizious.*" files, but original 
  dc-tool source code files remains unmodified, in order to keep the code 
  integrity.
     _____           ___ __    
    / ___/______ ___/ (_) /____
___/ /__/ __/ -_) _  / / __(_-<________________________________________________
   \___/_/  \__/\_,_/_/\__/___/ III. CREDiTS
                         
 ADK/Napalm, Cryptic Allusion, and every dc-tool and KallistiOS contributors.
 Greetings to all the Dreamcast Community.

 Feel free to contact me:
    www      : http://www.sizious.com/
    @        : sizious at gmail dot com
    Twitter  : twitter.com/@sizious
    Facebook : www.fb.com/sizious

 SiZiOUS '13.
 "Yeah, I know, my English sucks, sorry about that"