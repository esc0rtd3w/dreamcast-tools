/*
	DC-TOOL-SERIAL Patch for MinGW
	By SiZiOUS (sizious at gmail dot com)
	2013-03-02
*/
#include <windows.h>
#include <string.h>

/*
	For an obscure reason, the iberty library under MinGW doesn't seems to 
	contains the filename_ncmp (filename_cmp.c) function.
	So here is a ripped version from Internet...
*/

#define HAVE_CASE_INSENSITIVE_FILE_SYSTEM
#define HAVE_DOS_BASED_FILE_SYSTEM

#define TOLOWER tolower

int filename_ncmp (const char *s1, const char *s2, size_t n)
{
#if !defined(HAVE_DOS_BASED_FILE_SYSTEM) \
    && !defined(HAVE_CASE_INSENSITIVE_FILE_SYSTEM)
  return strncmp(s1, s2, n);
#else
  if (!n)
    return 0;
  for (; n > 0; --n)
  {
      int c1 = *s1;
      int c2 = *s2;

#if defined (HAVE_CASE_INSENSITIVE_FILE_SYSTEM)
      c1 = TOLOWER (c1);
      c2 = TOLOWER (c2);
#endif

#if defined (HAVE_DOS_BASED_FILE_SYSTEM)
      /* On DOS-based file systems, the '/' and the '\' are equivalent.  */
      if (c1 == '/')
        c1 = '\\';
      if (c2 == '/')
        c2 = '\\';
#endif

      if (c1 == '\0' || c1 != c2)
        return (c1 - c2);

      s1++;
      s2++;
  }
  return 0;
#endif
}
