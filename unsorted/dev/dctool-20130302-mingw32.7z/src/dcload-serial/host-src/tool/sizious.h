#ifndef __SIZIOUS_H__
#define __SIZIOUS_H__

int filename_ncmp (const char *, const char *, size_t);

#endif // __SIZIOUS_H__