#ifndef __SIZIOUS_H__
#define __SIZIOUS_H__

#include <winsock2.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <windows.h>
#include <errno.h>

#ifndef HAVE_STRUCT_TIMESPEC
#define HAVE_STRUCT_TIMESPEC 1
struct timespec {
        long tv_sec;
        long tv_nsec;
};
#endif /* HAVE_STRUCT_TIMESPEC */

int filename_ncmp (const char *, const char *, size_t);

// From libpthread
// Thanks Dongsheng Song <songdongsheng@live.cn>
#define MAX_SLEEP_IN_MS         4294967294UL
#define POW10_2     INT64_C(100)
#define POW10_3     INT64_C(1000)
#define POW10_4     INT64_C(10000)
#define POW10_6     INT64_C(1000000)
#define POW10_7     INT64_C(10000000)
#define POW10_9     INT64_C(1000000000)

int nanosleep(const struct timespec *, struct timespec *);

#endif // __SIZIOUS_H__