VMI Writer 1.0.5
Created by fackue
http://dchelp.dcemulation.com

Reads and Writes VMI files

What's new:
- added support for raw save icons with .hex extension
- went through the code, cleaned up a bit, improved things
- fixed "Check for Updates" to point to dcemulation.org
- bugs fixes

Credits:
- speud
- Marcus Comstedt
- quzar
- Sam Steel
- WaCk0

History:
1.0.4
- alpha icons supported
- saves with no icons and EXTRA.BG.PVR properly supported

1.0.3
- source cleaned
- a couple small changes
- check for updates

1.0.2a
- bug fix: fix checksum if the resource was longer then 4 characters

1.0.2
- bug fix: Date Overwrite would not uncheck
- VMS icon display
- VMI and VMS associated icons

1.0.1
- file association identifier is correct
- VMI filename is now shown when new VMI is saved
- replaced checksum checkbox with checksum label
- checksum is "Yes" after creating a new VMI
- VMI extention changed back to uppercase
- messageboxes, textboxes, and labels re-worded
- file association read/write/delete fixed
- file association executeable change check (again)
- type combo no long is left blank
- new "Fix checksum" for broken VMI checksums
- fixed loading a VMI with a resource less than 4 characters
- fixed loading a VMI with a bad creation date
- checks if the VMS file size field is left blank
- option to not overwrite the VMI creation date
- checks if the VMS file size is the actual VMS file size
- bad checksums are no longer overwritten unless fixed
- added icons to Open and Save buttons
- fixed dragging and dropping to the file vmiwriter.exe

1.0
- rewritten
- bug fixes
- new VMI read features (created date)
- new VMI write features (copy protect)
- other countless fixes

0.3
- Option to check if VMI/VMS are in the same directory
- Load button renamed to Open

0.2
- Description text and Copyright text can be left blank
- Fixed the VMSFileSizeText tab index
- SaveAs Filename is named as the Resource name
- Only numbers are allowed to be entered in VMSFileSizeText
- Load a VMS and auto-insert Resource and VMSFileSize
- Option to associate with VMI and VMS files
 
0.1
- Inital release