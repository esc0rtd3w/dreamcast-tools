DCStella ROMs list maker 0.1
Created by fackue
http://dchelp.dcemulation.com

I didn't like the rom list creaters for DCStella so I decided to create my own.
Differences: you can select the folder, select where you want to save the
rom list, leaves the filenames alone.

What's new:
- initial release

Thanks:
- burnerO
- svolli