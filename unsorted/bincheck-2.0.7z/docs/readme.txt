  [big_fury]
  888888888    8888  888888888888  8888     888888888     8888      8888   888888888
8888888888888  8888  888888888888  8888   8888888888888   8888      8888 8888888888888
8888     8888              88888         8888       8888  8888      8888 8888     8888
888888888      8888      888888    8888 8888         8888 8888      8888 888888888
  8888888888   8888     88888      8888 8888         8888 8888      8888   88888888888
       888888  8888   88888        8888 8888         8888 8888      8888         888888
8888      8888 8888  88888         8888  8888       8888  8888      8888 8888      8888
8888888888888  8888 88888888888888 8888   8888888888888    888888888888  8888888888888
  8888888888   8888 88888888888888 8888     888888888       8888888888     8888888888

"Read me isn't my passion"

BINCHECK.DLL Demo Test
======================

Version : v1.0
Autor   : [big_fury]SiZiOUS a.k.a SiZ!
Website : http://sbibuilder.shorturl.com/

I) Presentation : 
-----------------

Hello everyone! This program was made to test the new BINCHECK.DLL Delphi port
from LyingWake' Visual Basic source code. It'll NOT remplace the original 1st_read.bin
Checker, because it's very limited, it can only detect the bin state (yeah, yeah, that's it),
and scramble / unscramble the target file. Nothing else.

II) Use : 
---------

Before running this software, you must have a BINCHECK.DLL in your directory.

Run the software. Click the browse button to pick your binary. After that, just click the
"Test !" button. If you want you can Scramble/Unscramble the selected binary, for that just
click on Scramble/Unscramble buttons.

That's it :P

III) Credits : 
--------------

This app was programmed by [big_fury]SiZiOUS (SiZ!). 
It is freeware and can be distributed, if you keep the original package.
Original BINCHECK.DLL source code from LyingWake.

Enjoy it !!!

SiZ!

<EOF>