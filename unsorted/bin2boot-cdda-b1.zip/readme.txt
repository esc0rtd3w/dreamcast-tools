this is the first version of bin2boot that works with cdda
only basic cue routines are implemented as of now

The cue should look something like this:
FILE "KAL-CHU.BIN" BINARY
  TRACK 01 MODE1/2352
    INDEX 01 00:00:00
FILE "track_02.wav" WAVE
  TRACK 02 AUDIO
    INDEX 01 00:00:00
FILE "track_03.wav" WAVE
  TRACK 03 AUDIO
    INDEX 01 00:00:00

etc.. Just one track per file, one Index per track, and no pregap commands


IF IT LOOKS LIKE THIS IT WON'T WORK PROPERLY (note the multiple tracks in the same file):
FILE "kal-gl.bin" BINARY
  TRACK 02 MODE1/2352
    INDEX 01 00:00:00
  TRACK 03 AUDIO
    INDEX 00 66:06:38
    INDEX 01 66:08:38
  TRACK 04 AUDIO
    INDEX 01 66:12:38
  TRACK 05 AUDIO
    INDEX 01 66:20:39

This will be added in the next release.. So for now check your cue sheets before trying anything.. I released this version because it works with some, but you must remember that it won't work with all yet.

Try using cdrwin to extract a bin/cue/wav from your old discs. I haven't tried this but so long as the cue sheet is normal it should be fine.

Also, just like the other releases of bin2boot, the entire disc structure will remain the same.  It will load at the same speed as the non-boot.  You should be able to use AutoDummy with cdda games just like normal ones.

There were a few other small additions since the last release.  The file routine was improved again, I think it will work with every game now.  No "record for ip.bin not found" problem at all.  I tested this with NBA2K1 while fixing it.  Also, Virtua Cop 2 works now, you can load the "iso" like normal, or load the cue (this should be true with all the non-cdda games as well).

The original packs of Chu Chu Rocket, Roadsters, Mr. Driller, and a few others have worked fine with this release.