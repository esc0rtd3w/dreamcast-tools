  [big_fury]
  888888888    8888  888888888888  8888     888888888     8888      8888   888888888
8888888888888  8888  888888888888  8888   8888888888888   8888      8888 8888888888888
8888     8888              88888         8888       8888  8888      8888 8888     8888
888888888      8888      888888    8888 8888         8888 8888      8888 888888888
  8888888888   8888     88888      8888 8888         8888 8888      8888   88888888888
       888888  8888   88888        8888 8888         8888 8888      8888         888888
8888      8888 8888  88888         8888  8888       8888  8888      8888 8888      8888
8888888888888  8888 88888888888888 8888   8888888888888    888888888888  8888888888888
  8888888888   8888 88888888888888 8888     888888888       8888888888     8888888888

SBI Builder Wizard
==================

Version  : v3.2
Auteur   : [big_fury]SiZiOUS a.k.a SiZ!
Released : 30/11/06 at 05:19pm

I) Presentation : 
-----------------

Hello everyone! 

This program was build in order to create a SBI pack with a valid Dreamcast application, 
such an ELF or unscrambled/scrambled BIN file. SBI files are extensions for Selfboot Inducer.

You can use the lastest version (at this time), "Selfboot Inducer v4 Stage III : Ultimate Power",
available at my website : http://sbibuilder.shorturl.com/.

You can add a screenshot, a SBI comment, add extras files, etc.
For MAC Users, please check the box "MacDreamTool support", it add the SBI comment in a
file, called "<BINNAME>_comment.txt".

II) Use : 
---------

Very simple. You don't need a tutorial. If you want to learn more about it, please
visit the Fackue tutorial at :

"http://www.consolevision.com/members/fackue/tut_sbi.shtml".

III) Credits : 
--------------

This app was written by [big_fury]SiZiOUS (SiZ!). 
It's freeware and can be distributed, if you keep the original package.
Sorry for my very very baaaaaaaaad english, I'm THE worst in English :)

Thanks to you and burnerO for his Selfboot inducer ;)
And : patbier, oggy, C�dric, erwan, JMD, Diwee, pingouindream, L@ Cible, Eldrad Uhltran,
dcprogfr, goldzinger and all members from DCReload forum (http://www.dcreload.fr.st/).

Special thanks to Fackue, author of 1st_read.bin checker for his source!
Turrican2K (happy birthday ?) for his ELF2BIN package.
And, curt_grymala for SBI v4.0 informations.

Enjoy it !!!

[big_fury]SiZiOUS
http://sbibuilder.shorturl.com/
2002-2006 DC-Scene

<EOF>
