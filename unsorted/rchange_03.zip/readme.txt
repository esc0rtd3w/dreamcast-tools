Region Changer
Created by fackue
http://dchelp.dcemulation.com

Patches the Dreamcast's flash binary into your region, broadcast and language
of choice.

How it works:
Open your flash (dc_flash.bin), after it's loaded the current region state the
flash is in is set within the program. This is determind by the hex value at
&H1A002.

Japan (red swirl) - &H30
Japan (black swirl) - &H58
USA (red swirl) - &H31
USA (black swirl) - &H59
Europe (blue swirl) - &H32
Europe (black swirl) - &H5A

Broadcast is at &H1A003.

NTSC - &H30
PAL - &H31
PAL_M - &H32
PAL_N - &H33

Language is at &H1A004.

Japanese - &H30
English - &H31
German (Deutsch) - &H32
French (Fran�ais) - &H33
Spanish (Espa�ol) - &H34
Italian (Italiano) - &H35

Select your region by choosing one from the drop down list then click patch to
change the region.

What's new:

v0.3
- fixed a bug where broadcast & language read/write was swapped (PsyMan)
- added writes to shadowed region, broadcast and language locations (PsyMan)

v0.2
- broadcast & language values can be changed (SWAT)
- you can replace the default swirl with a black swirl (mathieulh)

v0.1
- initial release